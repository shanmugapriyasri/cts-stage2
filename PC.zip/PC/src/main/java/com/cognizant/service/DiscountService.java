package com.cognizant.service;

import com.cognizant.bean.ProductBean;

public interface DiscountService {
	double calculateDiscount(ProductBean product);
}
